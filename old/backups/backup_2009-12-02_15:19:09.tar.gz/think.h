
#ifndef THINK_H
#define THINK_H

typedef enum {
  EMPTY,
  BLACK,
  WHITE
} color_type;

typedef struct {
  color_type color;
  int group;
} vertex_type;

struct point_node_struct {
  int x;
  int y;
  struct point_node_struct *next;
};
typedef struct point_node_struct point_node;

struct board_node_struct {
  vertex_type *data;
  int numgroups;
  struct board_node_struct *children;
  struct board_node_struct *next;
};
typedef struct board_node_struct board_node;


void think_init();
void think_stop();

void think_clearboard();

void think_set_boardsize(int bsize);
void think_set_komi(float k);

int think_get_boardsize();

int think_generate_move(color_type color, int *x, int *y);
void think_make_move_on_board(color_type color, int x, int y);
int think_is_move_allowed(color_type color, int x, int y);

void think_show_board();
void think_show_groups();
void think_show_liberties();
void think_show_score();

#endif
